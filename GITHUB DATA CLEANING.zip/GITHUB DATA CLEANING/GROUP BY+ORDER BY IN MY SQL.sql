#groub by

SELECT *
FROM employee_demographics;


SELECT gender, AVG(age),MAX(age),MIN(age),COUNT(age)
FROM employee_demographics
GROUP BY gender
;

#order by
SELECT *
FROM employee_demographics
ORDER BY gender,age ;
