#window functions

SELECT gender,AVG(salary) AS avg_salary
FROM employee_demographics dem
JOIN employee_salary sal
	ON dem.employee_id = sal.employee_id
GROUP BY gender;


SELECT dem.first_name, dem.last_name,gender,AVG(salary) OVER(PARTITION BY gender)
FROM employee_demographics dem
JOIN employee_salary sal
	ON dem.employee_id = sal.employee_id;


SELECT dem.first_name,
 dem.last_name,
 gender,
 salary,
 SUM(salary) OVER(PARTITION BY gender ORDER BY dem.employee_id) AS ROLLING_TOTAL
FROM employee_demographics dem
JOIN employee_salary sal
	ON dem.employee_id = sal.employee_id;
    
    
    SELECT  dem.employee_id,
    dem.first_name,
 dem.last_name,
 gender,
 salary,
ROW_NUMBER() OVER(partition by gender ORDER BY salary DESC) AS row_num,
RANK() OVER(partition by gender ORDER BY salary DESC) AS rank_num,
dense_RANK() OVER(partition by gender ORDER BY salary DESC) AS dens rank_num
FROM employee_demographics dem
JOIN employee_salary sal
	ON dem.employee_id = sal.employee_id;
#major difff between row num and rank is that when coming across the same values rank acknowledges it 
#with the same number while row num does not
#dense rank gives the next number numerically not positionally lie rank does