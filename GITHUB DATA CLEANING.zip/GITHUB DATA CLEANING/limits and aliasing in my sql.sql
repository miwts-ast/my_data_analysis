#limit and aliasing

SELECT *
FROM employee_demographics
ORDER BY age DESC
LIMIT 5
;

#ALIASING
SELECT gender, AVG(age) AS avg_age
FROM employee_demographics
GROUP BY gender
HAVING avg_age>4;