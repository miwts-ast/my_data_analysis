#case statement

SELECT first_name,
last_name,
CASE
	WHEN age <= 30 THEN 'YOUNG'
    WHEN age BETWEEN 31 AND 50 THEN 'OLD'
    WHEN age >= 50 THEN 'ON DEATHS DOOR'
END AS age_bracket
FROM employee_demographics;

 #pay increase and bonus
 #< 50000= 5%
 #> 50000= 7%
# finance = 10% bonus


SELECT first_name,last_name,salary,
CASE
	WHEN salary < 50000 THEN salary + (salary * 0.05)
    WHEN salary > 50000 THEN salary + (salary * 0.07) 
END AS new_salary,
CASE
	WHEN dept_id = 6 THEN salary * .10
END AS bonus
FROM employee_salary;


SELECT *
FROM employee_salary;
SELECT *
FROM parks_departments;